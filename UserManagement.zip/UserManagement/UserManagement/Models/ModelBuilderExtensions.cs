﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UserManagement.Models
{
    public static class ModelBuilderExtensions
    {
        public static void Seed(this ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>().HasData(
                new User
                {
                    Id = 1,
                    Name = "Nitin",
                    Department = Dept.IT,
                    Email = "nitin@gmail.com"
                }, new User
                {
                    Id = 2,
                    Name = "John",
                    Department = Dept.HR,
                    Email = "john@gmail.com"
                }
                );
        }
    }
}
