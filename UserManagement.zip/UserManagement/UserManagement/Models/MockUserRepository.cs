﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UserManagement.Models
{
    public class MockUserRepository : IUserRepository
    {
        private List<User> _UserList;

        public MockUserRepository()
        {
            _UserList = new List<User>()
            {
                new User(){Id=1,Name="Mary", Department=Dept.HR, Email="mary@gmail.com"},
                new User(){Id=2,Name="John", Department=Dept.IT, Email="john@gmail.com"},
                new User(){Id=3,Name="Sam", Department=Dept.IT, Email="sam@gmail.com"}
            };
        }

        public User Add(User user)
        {
            user.Id = _UserList.Max(e => e.Id) + 1;
            _UserList.Add(user);
            return user;
        }

        public User Delete(int Id)
        {
            User user = _UserList.FirstOrDefault(e => e.Id == Id);
            if(user!=null)
            {
                _UserList.Remove(user);
            }
            return user;
        }

        public IEnumerable<User> GetAllUsers()
        {
            return _UserList;
        }

        public User GetUser(int id)
        {
            return _UserList.FirstOrDefault(u => u.Id == id);    
        }

        public User Update(User userChanges)
        {
            User user = _UserList.FirstOrDefault(e => e.Id == userChanges.Id);
            if(user!=null)
            {
                user.Name = userChanges.Name;
                user.Email = userChanges.Email;
                user.Department = userChanges.Department;
            }
            return user;
        }
    }
}
