﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using UserManagement.Models;
using UserManagement.Security;
using UserManagement.ViewModels;

namespace UserManagement.Controllers
{
    //[Route("Home")]
    //[Route("[controller]/[action]")]
    [Authorize(Roles = "Admin")]
    public class HomeController : Controller
    {
        private readonly IUserRepository _UserRepository;
        [Obsolete]
        private readonly IHostingEnvironment hostingEnvironment;
        public ILogger logger { get; }

        private readonly IDataProtector protector;

        [Obsolete]
        public HomeController(IUserRepository userRepository,  IHostingEnvironment  hostingEnvironment, ILogger<HomeController> logger,  IDataProtectionProvider dataProtectionProvider, DataProtectionPurposeStrings dataProtectionPurposeStrings)
        {
            _UserRepository = userRepository;
            this.hostingEnvironment = hostingEnvironment;
            this.logger = logger;
            protector = dataProtectionProvider.CreateProtector(dataProtectionPurposeStrings.UserIdRouteValue);
        }
         
        //[Route("Index")]
        //[Route("[action]")] 
        [AllowAnonymous]
        public ViewResult Index()
        {
            //return _UserRepository.GetUser(1).Name;
            var model = _UserRepository.GetAllUsers().Select(e =>
            {
                // Encrypt the ID value and store in EncryptedId property
                e.EncryptedId = protector.Protect(e.Id.ToString());
                return e;
            });
            return View(model);
        }

        //[Route("Details/{id?}")]
        [AllowAnonymous]
        public ViewResult Details(string id) //(int? id)
        {
            //throw new Exception("Error in Details View");
            logger.LogTrace("Trace Log");
            logger.LogDebug("Debug Log");
            logger.LogInformation("Information Log");
            logger.LogWarning("Warning Log");
            logger.LogError("Error Log");
            logger.LogCritical("Critical Log");



            //User user = _UserRepository.GetUser(id.Value);


            string decryptedId = protector.Unprotect(id);
            int decryptedIntId = Convert.ToInt32(decryptedId);
            User user = _UserRepository.GetUser(decryptedIntId);

            if (user ==null)
            {
                Response.StatusCode = 404;
                return View("UserNotFound", decryptedIntId); //id.Value);
            }

            HomeDetailsViewModel homeDetailsViewModel = new HomeDetailsViewModel()
            {
                User = user,
                PageTitle = "User Details"
            };
            return View(homeDetailsViewModel);

            //User model = _UserRepository.GetUser(1);
            //ViewBag.PageTitle = "User Details";
            //return View(model);

            //ViewBag.User = model;
            //ViewBag.PageTitle = "User Details";

            //ViewData["User"] = model;
            //ViewData["PageTitle"] = "User Details";
            //return View(model);

            //return View("Test");
            //return View("MyFolder/Test.cshtml"); absolute path
            //return View("../MyFolder/Test"); Relative path
        }

        [HttpGet]
        public ViewResult Create()
        {
            return View();
        }

        [HttpGet]
        public ViewResult Edit(int id)
        {
            User user = _UserRepository.GetUser(id);
            UserEditViewModel userEditViewModel = new UserEditViewModel
            {
                Id = user.Id,
                Name = user.Name,
                Email = user.Email,
                Department = user.Department,
                ExistingPhotoPath =user.PhotoPath
            };
            return View(userEditViewModel);
        }

        [HttpPost]
        [Obsolete]
        public IActionResult Edit(UserEditViewModel model)
        {
            if (ModelState.IsValid)
            {
                User user = _UserRepository.GetUser(model.Id);
                user.Name = model.Name;
                user.Email = model.Email;
                user.Department = model.Department;
                if(model.Photo !=null)
                {
                    if(model.ExistingPhotoPath != null)
                    {
                        string FilePath = Path.Combine(hostingEnvironment.WebRootPath, "images", model.ExistingPhotoPath);
                        System.IO.File.Delete(FilePath);
                    }
                    user.PhotoPath = ProcessUploadedFile(model);
                }                 
                _UserRepository.Update(user);
                return RedirectToAction("index");
            }
            return View();
        }

        [Obsolete]
        private string ProcessUploadedFile(UserCreateViewModel model)
        {
            string uniqueFileName = null;
            if (model.Photo != null)
            {
                string uploadsFolder = Path.Combine(hostingEnvironment.WebRootPath + "/images");
                uniqueFileName = Guid.NewGuid().ToString() + "_" + model.Photo.FileName;
                string filePath = Path.Combine(uploadsFolder, uniqueFileName);
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    model.Photo.CopyTo(fileStream);
                }

                // model.Photo.CopyTo(new FileStream(filePath, FileMode.Create));
            }

            return uniqueFileName;
        }

        [HttpPost]
        [Obsolete]
        public IActionResult Create(UserCreateViewModel model)
        {
            if (ModelState.IsValid)
            { 
                string uniqueFileName = ProcessUploadedFile(model);
                User newUser = new User { 
                Name  = model.Name,
                Email = model.Email,
                Department = model.Department,
                PhotoPath = uniqueFileName                
                };
                _UserRepository.Add(newUser);

                //User newUser = _UserRepository.Add(user);
                return RedirectToAction("details", new { id = newUser.Id });
            }
            return View();
        }
    }
}