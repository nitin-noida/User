﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserManagement.Models;

namespace UserManagement.ViewModels
{
    public class HomeDetailsViewModel
    {
        public User User { get; set; }
        public string PageTitle { get; set; }
    }
}
